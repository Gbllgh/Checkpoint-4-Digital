package com.fiap.checkpointdigital.services;

import com.fiap.checkpointdigital.entity.Livro;

import java.util.List;

public interface LivroService {
    List<Livro> listarLivros();
    Livro buscarLivroPorId(Long id);
    Livro adicionarLivro(Livro livro);
    Livro atualizarLivro(Long id, Livro livro);
    void removerLivro(Long id);
}