package com.fiap.checkpointdigital.strategy;

import com.fiap.checkpointdigital.entity.Livro;

import java.util.List;

public interface ClassificacaoStrategy {
    List<Livro> classificar(List<Livro> livros);
}

