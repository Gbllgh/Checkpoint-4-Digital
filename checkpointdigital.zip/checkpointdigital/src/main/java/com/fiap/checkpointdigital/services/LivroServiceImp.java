package com.fiap.checkpointdigital.services;

import com.fiap.checkpointdigital.entity.Livro;
import com.fiap.checkpointdigital.repository.LivroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LivroServiceImp implements LivroService {

    @Autowired
    private LivroRepository livroRepository;

    @Override
    public List<Livro> listarLivros() {
        return livroRepository.findAll();
    }

    @Override
    public Livro buscarLivroPorId(Long id) {
        return livroRepository.findById(id).orElse(null);
    }

    @Override
    public Livro adicionarLivro(Livro livro) {
        return livroRepository.save(livro);
    }

    @Override
    public Livro atualizarLivro(Long id, Livro livro) {
        livro.setId(id);
        return livroRepository.save(livro);
    }

    @Override
    public void removerLivro(Long id) {
        livroRepository.deleteById(id);
    }
}