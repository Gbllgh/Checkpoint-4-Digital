package com.fiap.checkpointdigital.strategy;

import com.fiap.checkpointdigital.entity.Livro;

import java.util.Comparator;
import java.util.List;

public class ClassificarPorTitulo implements ClassificacaoStrategy {

    @Override
    public List<Livro> classificar(List<Livro> livros) {
        livros.sort(Comparator.comparing(Livro::getTitulo));
        return livros;
    }
}
