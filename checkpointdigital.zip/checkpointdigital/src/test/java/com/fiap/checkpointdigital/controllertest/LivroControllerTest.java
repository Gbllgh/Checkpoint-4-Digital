package com.fiap.checkpointdigital.controllertest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fiap.checkpointdigital.entity.Livro;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class LivroControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void testAdicionarLivroCenarioFeliz() throws Exception {
        Livro livro = new Livro();
        livro.setTitulo("Livro Teste");
        livro.setAutores("Autor Teste");
        livro.setAnoPublicacao(2022);
        livro.setCategoria("Teste");

        mockMvc.perform(post("/livros")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(livro)))
                .andExpect(status().isOk());
    }

    @Test
    public void testAdicionarLivroExcecao() throws Exception {
        Livro livro = new Livro(); // Criando um livro com informações incompletas

        mockMvc.perform(post("/livros")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(livro)))
                .andExpect(status().isBadRequest());
    }
}