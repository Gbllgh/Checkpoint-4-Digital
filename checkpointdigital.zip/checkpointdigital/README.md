Gustavo Ballogh RM:96542
Maria Luiza de Goveia Lima RM:97569


Realizado no projeto - 
Maria: Entity - Repository - Services 
Gustavo: Controller - Strategy - Test